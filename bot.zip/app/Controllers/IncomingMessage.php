<?php

namespace App\Controllers;

class IncomingMessage extends BaseController
{
    private $defaultMessage = [
        '/menu' => ['message' => [
            'text' => 'Daftar menu easywa',
            'footer' => 'link: http://easywa.web.id',
            'title' => 'mudahkan jangan dipersulit',
            'buttonText' => 'Klik saya untuk melihat menu utama',
            'sections' => [
                [
                    'title' => 'Pendaftaran',
                    'rows' => [
                        [
                            'title' => '/register',
                            'rowId' => 'register1',
                        ],
                        [
                            'title' => '/status',
                            'rowId' => 'status1',
                            'description' => 'Mengecek status',
                        ],
                    ],
                ],
                [
                    'title' => 'Diskusi',
                    'rows' => [
                        [
                            'title' => '/faq',
                            'rowId' => 'faq',
                        ],
                        [
                            'title' => '/ask',
                            'rowId' => 'ask'                            
                        ],
                    ],
                ],
            ],
        ]],
        '/register' => ['message' => [
            'text' => 'Untuk registrasi silakan kunjungi',
            'templateButtons' => [
            [
                'index' => 1,
                'urlButton' => [
                    'displayText' => 'Daftar disini',
                    'url' => 'https://easywa.web.id',
                ],
            ],
            [
                'index' => 2,
                'callButton' => [
                    'displayText' => 'Telpon',
                    'phoneNumber' => '+6285733659400',
                ],
            ]],
            ]
        ],
        '/status' => ['message' => ['text' => 'Status masih dirahasiakan']],
        '/faq' => ['message' => ['text' => 'Daftar pertanyaan yang sering ditanyakan']],
        '/ask' => ['message' => ['text' => 'Permintaan fitur baru']],        
    ];

    private $notFoundMessage = ['message' => ['text' => 'Jawaban {{message}} tidak ditemukan']];
    public function index()
    {
        $message = trim($this->request->getPost('message'));
        $sender = $this->request->getPost('sender');        
        $replyMessage = $this->getResponseMessage($message);
        $this->sendWhatsapp($sender, $replyMessage);
        $this->response->setStatusCode(201, 'message created');
    }

    private function getResponseMessage($message)
    {        
        return $this->defaultMessage[$message] ?? $this->getNotFoundMessage($message);
        
    }

    private function sendWhatsapp($to, $message){        
        if(\str_contains($to, '@g.us')){

            return;
        }
        $message['to'] = $to;
        $easywa = config('Easywa');        
        $client = \Config\Services::curlrequest([
            'baseURI' => "{$easywa->server}/sendmessage?number={$easywa->number}",
        ]);
        $client->post('', ['json' => $message]);
    }

    /**
     * Get the value of notFoundMessage
     */ 
    public function getNotFoundMessage($message)
    {
        $this->notFoundMessage['message']['text'] = str_replace('{{message}}', '*'.$message.'*', $this->notFoundMessage['message']['text']);        
        return $this->notFoundMessage;
    }
}
