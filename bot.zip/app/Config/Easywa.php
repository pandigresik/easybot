<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Easywa extends BaseConfig
{    
    public $server = 'http://localhost:3000';
    public $number = '';
}
